/*************************************************************************************
 Title:     PS/2 library
 Author:    Jan Pieter de Ruiter <janpieterd@lycos.nl>
 Date:      13-Jun-2002
 Software:  AVR-GCC with AvrStudio
 Target:    Any AVR device.

 DESCRIPTION
       Basic routines for implementing the ps/2 protocol (for a mouse, keyboard etc.)
       where the microcontroller acts as a "host"
       
       See http://panda.cs.ndsu.nodak.edu/~achapwes/PICmicro/ps2/ps2.html
       and http://panda.cs.ndsu.nodak.edu/~achapwes/PICmicro/mouse/mouse.html
       and http://panda.cs.ndsu.nodak.edu/~achapwes/PICmicro/keyboard/atkeyboard.html
       for more info

 USAGE
       See the C include ps2.h file for a description of each function
       
**************************************************************************************/
#include "ps2.h"
#include <io.h>

void delay(long microseconds)
{
	while(microseconds)microseconds--;	// Wait about "microseconds" microseconds (@ 4MHz oscillator)
}

int Read_ps2data(void)
{	
	int d[8];
	int i,parity;
	int f=1;
	int data=0;
	
	cbi(CLKDDR,CLK);             // Make CLK input
	cbi(DATADDR,DATA);           // Make DATA input     
	cbi(CLKPORT,CLK);            // Make CLK open
	cbi(DATAPORT,DATA);          // Make CLK open
	
	loop_until_bit_is_clear(CLKPIN,CLK);     // Ignore startbit
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);     // Receive first databit
	if(bit_is_set(DATAPIN,DATA))d[0]=1;
	else d[0]=0;
	loop_until_bit_is_set(CLKPIN,CLK);

	loop_until_bit_is_clear(CLKPIN,CLK);     // Receive second databit
	if(bit_is_set(DATAPIN,DATA))d[1]=1;
	else d[1]=0;
	loop_until_bit_is_set(CLKPIN,CLK);

	loop_until_bit_is_clear(CLKPIN,CLK);     // etc.
	if(bit_is_set(DATAPIN,DATA))d[2]=1;
	else d[2]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if(bit_is_set(DATAPIN,DATA))d[3]=1;
	else d[3]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if(bit_is_set(DATAPIN,DATA))d[4]=1;
	else d[4]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if(bit_is_set(DATAPIN,DATA))d[5]=1;
	else d[5]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if(bit_is_set(DATAPIN,DATA))d[6]=1;
	else d[6]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if(bit_is_set(DATAPIN,DATA))d[7]=1;
	else d[7]=0;
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);     // Receive parity bit
	if(bit_is_set(DATAPIN,DATA))parity=0;
	else parity=1;
	loop_until_bit_is_set(CLKPIN,CLK);

	loop_until_bit_is_clear(CLKPIN,CLK);     // Ignore stop bit
	loop_until_bit_is_set(CLKPIN,CLK);
	f=1;
	for(i=0;i<8;i++)   // Put all received bits in data
	{
		data+=d[i]*f;
		f*=2;
	}
	if(((parity==0)&&(parity_even_bit(data)==0))||((parity!=0)&&(parity_even_bit(data)!=0)))return data;   // Return data if received data is OK 
	else
	{
		Write_ps2data(0xFE);      // Send the "ReSend" commando
		return Read_ps2data();    // Receive data again
	}
}

void Write_ps2data(int data)
{
	cbi(DATADDR,DATA);       // Make DATA input
	cbi(DATAPORT,DATA);      // Make DATA open
	sbi(CLKDDR,CLK);         // Make CLK output
	cbi(CLKPORT,CLK);        // Make CLK open
	
	cbi(CLKPORT,CLK);	       // Cancel the mouse (if transmitting)
	delay(100);
	sbi(DATADDR,DATA);       // Make DATA output
	cbi(DATAPORT,DATA);      // Generate startbit
	delay(100);
	cbi(CLKDDR,CLK);         // Make CLK input
	cbi(CLKPORT,CLK);        // Make CLK open
	
	loop_until_bit_is_clear(CLKPIN,CLK);     // Send first data bit
	if((data&0x01)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);     // Send first data bit
	if((data&0x02)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
													
	loop_until_bit_is_clear(CLKPIN,CLK);     // etc.
	if((data&0x04)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if((data&0x08)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if((data&0x10)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if((data&0x20)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if((data&0x40)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);
	if((data&0x80)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	loop_until_bit_is_clear(CLKPIN,CLK);             // Send parity bit
	if(parity_even_bit(data)==0)cbi(DATAPORT,DATA);
	else sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);

	loop_until_bit_is_clear(CLKPIN,CLK);         // Send stop bit
	sbi(DATAPORT,DATA);
	loop_until_bit_is_set(CLKPIN,CLK);
	
	cbi(DATADDR,DATA);
	cbi(DATAPORT,DATA);
	cbi(CLKDDR,CLK);
	cbi(CLKPORT,CLK);
	loop_until_bit_is_clear(CLKPIN,CLK);    // Ignore acknowledge bit
	loop_until_bit_is_set(CLKPIN,CLK);
}
