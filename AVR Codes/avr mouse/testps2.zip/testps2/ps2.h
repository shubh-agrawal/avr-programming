/*************************************************************************************
 Title:     C include file for the PS/2 library (ps2.c)
 Author:    Jan Pieter de Ruiter <janpieterd@lycos.nl>
 Date:      13-Jun-2002
 Software:  AVR-GCC with AvrStudio
 Target:    Any AVR device

 DESCRIPTION
       Basic routines for implementing the ps/2 protocol (for a mouse, keyboard etc.)

**************************************************************************************/
#ifndef __PS2_H_
#define __PS2_H_ 1

/* Select ports for the CLK and DATA lines here **************/
#define CLKPORT 	PORTA    // port for CLK line
#define DATAPORT 	PORTA    // port for DATA line
#define CLK			0        // pin on CLKPORT for CLK line
#define DATA		1        // pin on DATAPORT for DATA line
/*************************************************************/

/* You don't have to change anything below */
#define CLKDDR		CLKPORT-1
#define CLKPIN		CLKPORT-2
#define DATADDR	DATAPORT-1
#define DATAPIN	DATAPORT-2
/*******************************************/

void delay(long microseconds);   // Function for internal usage
int Read_ps2data(void);          // Receives a data byte from a device
void Write_ps2data(int data);    // Sends a data byte to a device

#endif
